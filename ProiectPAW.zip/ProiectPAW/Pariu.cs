﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class Pariu
    {
        public int cod;
        public string simbol;
        public string denumire;
        public double cota;
        public bool status;
        public Meci meci;

        public Pariu(string s, Meci m, double c)
        {
            simbol = s;
            meci = m;
            cota = c;

        }

        public override string ToString()
        {
            return "A fost introdus pe meciul " + meci.denumire + " pariul " + denumire;
        }
        public bool rezultatPronostic(Pariu p1)
        {
            p1.status = false;
            if ((meci.scorEchipa1 > meci.scorEchipa2) && (p1.simbol == "1"))
                p1.status = true;
            else if ((meci.scorEchipa1 < meci.scorEchipa2) && (p1.simbol == "2"))
                p1.status = true;
            else if ((meci.scorEchipa1 == meci.scorEchipa2) && (p1.simbol == "X"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) >= 0 && (meci.scorEchipa1 + meci.scorEchipa2) <= 2 && (p1.simbol == "0-2"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) >= 1 && (meci.scorEchipa1 + meci.scorEchipa2) <= 3 && (p1.simbol == "1-3"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) >= 3 && (meci.scorEchipa1 + meci.scorEchipa2) <= 5 && (p1.simbol == "3-5"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) > 1 && (p1.simbol == "P 1.5"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) > 2 && (p1.simbol == "P 2.5"))
                p1.status = true;
            else if ((meci.scorEchipa1 + meci.scorEchipa2) > 3 && (p1.simbol == "P 3.5"))
                p1.status = true;
            else if ((meci.scorEchipa1 > 0) && (meci.scorEchipa2 > 0) && (p1.simbol == "GG"))
                p1.status = true;
            else if ((meci.scorEchipa1 >= 3) && (meci.scorEchipa2 >= 3) && (p1.simbol == "GG3+"))
                p1.status = true;
            else if (((meci.scorEchipa1 == 0) && (meci.scorEchipa2 == 3) && (p1.simbol == "NGG")))
                p1.status = true;

                return p1.status;
        }
    } 
}

