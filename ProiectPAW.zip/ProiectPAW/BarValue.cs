﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectPAW
{
    public class BarValue
    {   
        public string label;
        public int Value;

        public BarValue(int i, string l)
        {
            label = l;
            Value = i;
        }
    
    }
}
    

