﻿
namespace ProiectPAW
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.MenuStrip Oferta;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.toolStripMenuItemOfertaFotbal = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemOfertaHandbal = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemOfertaRugby = new System.Windows.Forms.ToolStripMenuItem();
            this.listViewBilet = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemSalveazaF = new System.Windows.Forms.ToolStripMenuItem();
            this.listViewOferta = new System.Windows.Forms.ListView();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader17 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader18 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader19 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader20 = new System.Windows.Forms.ColumnHeader();
            this.textBoxCota = new System.Windows.Forms.TextBox();
            this.textBoxPret = new System.Windows.Forms.TextBox();
            this.labelPret = new System.Windows.Forms.Label();
            this.labelCota = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonAdaugaBilet = new System.Windows.Forms.Button();
            this.textBoxSansaCastig = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox35G = new System.Windows.Forms.CheckBox();
            this.checkBox13G = new System.Windows.Forms.CheckBox();
            this.checkBox02G = new System.Windows.Forms.CheckBox();
            this.checkBox1Final = new System.Windows.Forms.CheckBox();
            this.checkBox2Final = new System.Windows.Forms.CheckBox();
            this.checkBoxXFInal = new System.Windows.Forms.CheckBox();
            this.checkBoxP35 = new System.Windows.Forms.CheckBox();
            this.checkBoxP25 = new System.Windows.Forms.CheckBox();
            this.checkBoxP15 = new System.Windows.Forms.CheckBox();
            this.checkBoxNGG = new System.Windows.Forms.CheckBox();
            this.checkBoxGG3 = new System.Windows.Forms.CheckBox();
            this.CheckBoxGG = new System.Windows.Forms.CheckBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            Oferta = new System.Windows.Forms.MenuStrip();
            Oferta.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Oferta
            // 
            Oferta.ImageScalingSize = new System.Drawing.Size(20, 20);
            Oferta.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemOfertaFotbal,
            this.toolStripMenuItemOfertaHandbal,
            this.toolStripMenuItemOfertaRugby});
            Oferta.Location = new System.Drawing.Point(0, 24);
            Oferta.Name = "Oferta";
            Oferta.Size = new System.Drawing.Size(1778, 28);
            Oferta.TabIndex = 31;
            Oferta.Text = "menuStrip1";
            // 
            // toolStripMenuItemOfertaFotbal
            // 
            this.toolStripMenuItemOfertaFotbal.Name = "toolStripMenuItemOfertaFotbal";
            this.toolStripMenuItemOfertaFotbal.Size = new System.Drawing.Size(111, 24);
            this.toolStripMenuItemOfertaFotbal.Text = "Oferta Fotbal";
            this.toolStripMenuItemOfertaFotbal.Click += new System.EventHandler(this.toolStripMenuItemOfertaFotbal_Click);
            // 
            // toolStripMenuItemOfertaHandbal
            // 
            this.toolStripMenuItemOfertaHandbal.Name = "toolStripMenuItemOfertaHandbal";
            this.toolStripMenuItemOfertaHandbal.Size = new System.Drawing.Size(126, 24);
            this.toolStripMenuItemOfertaHandbal.Text = "Oferta Handbal";
            this.toolStripMenuItemOfertaHandbal.Click += new System.EventHandler(this.toolStripMenuItemOfertaHandbal_Click);
            // 
            // toolStripMenuItemOfertaRugby
            // 
            this.toolStripMenuItemOfertaRugby.Name = "toolStripMenuItemOfertaRugby";
            this.toolStripMenuItemOfertaRugby.Size = new System.Drawing.Size(111, 24);
            this.toolStripMenuItemOfertaRugby.Text = "Oferta Rugby";
            this.toolStripMenuItemOfertaRugby.Click += new System.EventHandler(this.toolStripMenuItemOfertaRugby_Click);
            // 
            // listViewBilet
            // 
            this.listViewBilet.AllowDrop = true;
            this.listViewBilet.BackColor = System.Drawing.Color.Chartreuse;
            this.listViewBilet.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewBilet.ContextMenuStrip = this.contextMenuStrip1;
            this.listViewBilet.FullRowSelect = true;
            this.listViewBilet.HideSelection = false;
            this.listViewBilet.Location = new System.Drawing.Point(43, 87);
            this.listViewBilet.Name = "listViewBilet";
            this.listViewBilet.Size = new System.Drawing.Size(372, 295);
            this.listViewBilet.TabIndex = 0;
            this.listViewBilet.UseCompatibleStateImageBehavior = false;
            this.listViewBilet.View = System.Windows.Forms.View.Details;
            this.listViewBilet.DragDrop += new System.Windows.Forms.DragEventHandler(this.listViewBilet_DragDrop);
            this.listViewBilet.DragOver += new System.Windows.Forms.DragEventHandler(this.listViewBilet_DragOver);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Meci";
            this.columnHeader1.Width = 130;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Pariu";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Cota";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Ora meci";
            this.columnHeader4.Width = 120;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemPrint,
            this.toolStripMenuItemSalveazaF});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(182, 52);
            // 
            // toolStripMenuItemPrint
            // 
            this.toolStripMenuItemPrint.Name = "toolStripMenuItemPrint";
            this.toolStripMenuItemPrint.Size = new System.Drawing.Size(181, 24);
            this.toolStripMenuItemPrint.Text = "Imprimare Bilet";
            this.toolStripMenuItemPrint.Click += new System.EventHandler(this.toolStripMenuItemPrint_Click);
            // 
            // toolStripMenuItemSalveazaF
            // 
            this.toolStripMenuItemSalveazaF.Name = "toolStripMenuItemSalveazaF";
            this.toolStripMenuItemSalveazaF.Size = new System.Drawing.Size(181, 24);
            this.toolStripMenuItemSalveazaF.Text = "Salveaza fisier";
            this.toolStripMenuItemSalveazaF.Click += new System.EventHandler(this.toolStripMenuItemSalveazaF_Click);
            // 
            // listViewOferta
            // 
            this.listViewOferta.BackColor = System.Drawing.Color.Chartreuse;
            this.listViewOferta.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20});
            this.listViewOferta.Cursor = System.Windows.Forms.Cursors.Default;
            this.listViewOferta.FullRowSelect = true;
            this.listViewOferta.GridLines = true;
            this.listViewOferta.HideSelection = false;
            this.listViewOferta.Location = new System.Drawing.Point(517, 87);
            this.listViewOferta.Name = "listViewOferta";
            this.listViewOferta.Size = new System.Drawing.Size(1185, 215);
            this.listViewOferta.TabIndex = 1;
            this.listViewOferta.UseCompatibleStateImageBehavior = false;
            this.listViewOferta.View = System.Windows.Forms.View.Details;
            this.listViewOferta.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.listViewOferta_ItemDrag);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Meci";
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "1";
            this.columnHeader6.Width = 140;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "2";
            this.columnHeader7.Width = 140;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Ora";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "1";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "2";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "X";
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "0-2";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "1-3";
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "3-5";
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "P 1.5";
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "P 2.5";
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "P 3.5";
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "GG";
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "GG3+";
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "NGG";
            // 
            // textBoxCota
            // 
            this.textBoxCota.Enabled = false;
            this.textBoxCota.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxCota.Location = new System.Drawing.Point(232, 538);
            this.textBoxCota.Name = "textBoxCota";
            this.textBoxCota.ReadOnly = true;
            this.textBoxCota.Size = new System.Drawing.Size(125, 29);
            this.textBoxCota.TabIndex = 2;
            // 
            // textBoxPret
            // 
            this.textBoxPret.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxPret.Location = new System.Drawing.Point(234, 433);
            this.textBoxPret.Name = "textBoxPret";
            this.textBoxPret.Size = new System.Drawing.Size(125, 29);
            this.textBoxPret.TabIndex = 3;
            this.textBoxPret.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxPret_Validating);
            // 
            // labelPret
            // 
            this.labelPret.AutoSize = true;
            this.labelPret.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelPret.ForeColor = System.Drawing.Color.Yellow;
            this.labelPret.Location = new System.Drawing.Point(43, 433);
            this.labelPret.Name = "labelPret";
            this.labelPret.Size = new System.Drawing.Size(42, 20);
            this.labelPret.TabIndex = 4;
            this.labelPret.Text = "Pret";
            // 
            // labelCota
            // 
            this.labelCota.AutoSize = true;
            this.labelCota.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCota.ForeColor = System.Drawing.Color.Yellow;
            this.labelCota.Location = new System.Drawing.Point(43, 541);
            this.labelCota.Name = "labelCota";
            this.labelCota.Size = new System.Drawing.Size(48, 20);
            this.labelCota.TabIndex = 5;
            this.labelCota.Text = "Cota";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(156, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 29);
            this.label1.TabIndex = 6;
            this.label1.Text = "BILET";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(972, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "OFERTA DE AZI";
            // 
            // buttonAdaugaBilet
            // 
            this.buttonAdaugaBilet.BackColor = System.Drawing.Color.Honeydew;
            this.buttonAdaugaBilet.ForeColor = System.Drawing.Color.DarkGreen;
            this.buttonAdaugaBilet.Location = new System.Drawing.Point(664, 671);
            this.buttonAdaugaBilet.Name = "buttonAdaugaBilet";
            this.buttonAdaugaBilet.Size = new System.Drawing.Size(636, 29);
            this.buttonAdaugaBilet.TabIndex = 8;
            this.buttonAdaugaBilet.Text = "Adauga Bilet";
            this.buttonAdaugaBilet.UseVisualStyleBackColor = false;
            this.buttonAdaugaBilet.Click += new System.EventHandler(this.buttonAdaugaBilet_Click);
            // 
            // textBoxSansaCastig
            // 
            this.textBoxSansaCastig.Enabled = false;
            this.textBoxSansaCastig.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxSansaCastig.Location = new System.Drawing.Point(234, 651);
            this.textBoxSansaCastig.Name = "textBoxSansaCastig";
            this.textBoxSansaCastig.ReadOnly = true;
            this.textBoxSansaCastig.Size = new System.Drawing.Size(125, 29);
            this.textBoxSansaCastig.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(43, 654);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Castig potential";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(966, 329);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(222, 29);
            this.button1.TabIndex = 15;
            this.button1.Text = "Afiseaza oferta de azi";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox35G
            // 
            this.checkBox35G.AutoSize = true;
            this.checkBox35G.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox35G.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBox35G, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBox35G.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBox35G.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.checkBox35G.Location = new System.Drawing.Point(812, 582);
            this.checkBox35G.Name = "checkBox35G";
            this.checkBox35G.Size = new System.Drawing.Size(129, 48);
            this.checkBox35G.TabIndex = 17;
            this.checkBox35G.Text = "          3-5";
            this.checkBox35G.UseVisualStyleBackColor = true;
            // 
            // checkBox13G
            // 
            this.checkBox13G.AutoSize = true;
            this.checkBox13G.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox13G.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBox13G, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBox13G.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBox13G.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox13G.Location = new System.Drawing.Point(812, 532);
            this.checkBox13G.Name = "checkBox13G";
            this.checkBox13G.Size = new System.Drawing.Size(129, 48);
            this.checkBox13G.TabIndex = 19;
            this.checkBox13G.Text = "          1-3";
            this.checkBox13G.UseVisualStyleBackColor = true;
            // 
            // checkBox02G
            // 
            this.checkBox02G.AutoSize = true;
            this.checkBox02G.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox02G.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBox02G, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBox02G.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBox02G.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox02G.Location = new System.Drawing.Point(812, 474);
            this.checkBox02G.Name = "checkBox02G";
            this.checkBox02G.Size = new System.Drawing.Size(129, 48);
            this.checkBox02G.TabIndex = 20;
            this.checkBox02G.Text = "          0-2";
            this.checkBox02G.UseVisualStyleBackColor = true;
            // 
            // checkBox1Final
            // 
            this.checkBox1Final.AutoSize = true;
            this.checkBox1Final.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox1Final.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBox1Final, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBox1Final.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBox1Final.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox1Final.Location = new System.Drawing.Point(692, 474);
            this.checkBox1Final.Name = "checkBox1Final";
            this.checkBox1Final.Size = new System.Drawing.Size(111, 48);
            this.checkBox1Final.TabIndex = 22;
            this.checkBox1Final.Text = "          1";
            this.checkBox1Final.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1Final.UseVisualStyleBackColor = true;
            // 
            // checkBox2Final
            // 
            this.checkBox2Final.AutoSize = true;
            this.checkBox2Final.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBox2Final.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBox2Final, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBox2Final.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBox2Final.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox2Final.Location = new System.Drawing.Point(692, 532);
            this.checkBox2Final.Name = "checkBox2Final";
            this.checkBox2Final.Size = new System.Drawing.Size(111, 48);
            this.checkBox2Final.TabIndex = 23;
            this.checkBox2Final.Text = "          2";
            this.checkBox2Final.UseVisualStyleBackColor = true;
            // 
            // checkBoxXFInal
            // 
            this.checkBoxXFInal.AutoSize = true;
            this.checkBoxXFInal.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxXFInal.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxXFInal, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxXFInal.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxXFInal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxXFInal.Location = new System.Drawing.Point(692, 582);
            this.checkBoxXFInal.Name = "checkBoxXFInal";
            this.checkBoxXFInal.Size = new System.Drawing.Size(113, 48);
            this.checkBoxXFInal.TabIndex = 24;
            this.checkBoxXFInal.Text = "          X";
            this.checkBoxXFInal.UseVisualStyleBackColor = true;
            // 
            // checkBoxP35
            // 
            this.checkBoxP35.AutoSize = true;
            this.checkBoxP35.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxP35.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxP35, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxP35.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxP35.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxP35.Location = new System.Drawing.Point(947, 582);
            this.checkBoxP35.Name = "checkBoxP35";
            this.checkBoxP35.Size = new System.Drawing.Size(149, 48);
            this.checkBoxP35.TabIndex = 25;
            this.checkBoxP35.Text = "           P 3.5";
            this.checkBoxP35.UseVisualStyleBackColor = true;
            this.checkBoxP35.CheckedChanged += new System.EventHandler(this.checkBoxP35_CheckedChanged);
            // 
            // checkBoxP25
            // 
            this.checkBoxP25.AutoSize = true;
            this.checkBoxP25.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxP25.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxP25, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxP25.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxP25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxP25.Location = new System.Drawing.Point(947, 532);
            this.checkBoxP25.Name = "checkBoxP25";
            this.checkBoxP25.Size = new System.Drawing.Size(149, 48);
            this.checkBoxP25.TabIndex = 26;
            this.checkBoxP25.Text = "           P 2.5";
            this.checkBoxP25.UseVisualStyleBackColor = true;
            // 
            // checkBoxP15
            // 
            this.checkBoxP15.AutoSize = true;
            this.checkBoxP15.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxP15.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxP15, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxP15.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxP15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxP15.Location = new System.Drawing.Point(947, 474);
            this.checkBoxP15.Name = "checkBoxP15";
            this.checkBoxP15.Size = new System.Drawing.Size(149, 48);
            this.checkBoxP15.TabIndex = 27;
            this.checkBoxP15.Text = "           P 1.5";
            this.checkBoxP15.UseVisualStyleBackColor = true;
            // 
            // checkBoxNGG
            // 
            this.checkBoxNGG.AutoSize = true;
            this.checkBoxNGG.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxNGG.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxNGG, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxNGG.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxNGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxNGG.Location = new System.Drawing.Point(1102, 582);
            this.checkBoxNGG.Name = "checkBoxNGG";
            this.checkBoxNGG.Size = new System.Drawing.Size(120, 48);
            this.checkBoxNGG.TabIndex = 28;
            this.checkBoxNGG.Text = "        NGG";
            this.checkBoxNGG.UseVisualStyleBackColor = true;
            this.checkBoxNGG.CheckedChanged += new System.EventHandler(this.checkBoxNGG_CheckedChanged);
            // 
            // checkBoxGG3
            // 
            this.checkBoxGG3.AutoSize = true;
            this.checkBoxGG3.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.checkBoxGG3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.checkBoxGG3, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.checkBoxGG3.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.checkBoxGG3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBoxGG3.Location = new System.Drawing.Point(1102, 532);
            this.checkBoxGG3.Name = "checkBoxGG3";
            this.checkBoxGG3.Size = new System.Drawing.Size(126, 48);
            this.checkBoxGG3.TabIndex = 29;
            this.checkBoxGG3.Text = "        GG3+";
            this.checkBoxGG3.UseVisualStyleBackColor = true;
            // 
            // CheckBoxGG
            // 
            this.CheckBoxGG.AutoSize = true;
            this.CheckBoxGG.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CheckBoxGG.ForeColor = System.Drawing.SystemColors.WindowText;
            this.errorProvider1.SetIconAlignment(this.CheckBoxGG, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
            this.CheckBoxGG.Image = global::ProiectPAW.Properties.Resources.Double_J_Design_Ravenna_3d_Poker;
            this.CheckBoxGG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBoxGG.Location = new System.Drawing.Point(1102, 474);
            this.CheckBoxGG.Name = "CheckBoxGG";
            this.CheckBoxGG.Size = new System.Drawing.Size(108, 48);
            this.CheckBoxGG.TabIndex = 30;
            this.CheckBoxGG.Text = "        GG";
            this.CheckBoxGG.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Image = global::ProiectPAW.Properties.Resources.download3;
            this.button2.Location = new System.Drawing.Point(1565, 657);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(208, 42);
            this.button2.TabIndex = 32;
            this.button2.Text = "&P";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Green;
            this.pictureBox1.BackgroundImage = global::ProiectPAW.Properties.Resources.soccer_icon;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(860, 329);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(81, 109);
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::ProiectPAW.Properties.Resources.Football_icon;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(1208, 329);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(81, 109);
            this.pictureBox2.TabIndex = 34;
            this.pictureBox2.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1778, 24);
            this.menuStrip1.TabIndex = 35;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1778, 711);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.CheckBoxGG);
            this.Controls.Add(this.checkBoxGG3);
            this.Controls.Add(this.checkBoxNGG);
            this.Controls.Add(this.checkBoxP15);
            this.Controls.Add(this.checkBoxP25);
            this.Controls.Add(this.checkBoxP35);
            this.Controls.Add(this.checkBoxXFInal);
            this.Controls.Add(this.checkBox2Final);
            this.Controls.Add(this.checkBox1Final);
            this.Controls.Add(this.checkBox02G);
            this.Controls.Add(this.checkBox13G);
            this.Controls.Add(this.checkBox35G);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxSansaCastig);
            this.Controls.Add(this.buttonAdaugaBilet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelCota);
            this.Controls.Add(this.labelPret);
            this.Controls.Add(this.textBoxPret);
            this.Controls.Add(this.textBoxCota);
            this.Controls.Add(this.listViewOferta);
            this.Controls.Add(this.listViewBilet);
            this.Controls.Add(Oferta);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.ShowIcon = false;
            this.Text = "BILET";
            this.TransparencyKey = System.Drawing.Color.Silver;
            Oferta.ResumeLayout(false);
            Oferta.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewBilet;
        private System.Windows.Forms.ListView listViewOferta;
        private System.Windows.Forms.TextBox textBoxCota;
        private System.Windows.Forms.TextBox textBoxPret;
        private System.Windows.Forms.Label labelPret;
        private System.Windows.Forms.Label labelCota;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonAdaugaBilet;
        private System.Windows.Forms.TextBox textBoxSansaCastig;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.CheckBox checkBox35G;
        private System.Windows.Forms.CheckBox checkBox13G;
        private System.Windows.Forms.CheckBox checkBox02G;
        private System.Windows.Forms.CheckBox checkBox1Final;
        private System.Windows.Forms.CheckBox checkBox2Final;
        private System.Windows.Forms.CheckBox checkBoxXFInal;
        private System.Windows.Forms.CheckBox checkBoxP35;
        private System.Windows.Forms.CheckBox checkBoxP25;
        private System.Windows.Forms.CheckBox checkBoxP15;
        private System.Windows.Forms.CheckBox checkBoxNGG;
        private System.Windows.Forms.CheckBox checkBoxGG3;
        private System.Windows.Forms.CheckBox CheckBoxGG;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemOfertaFotbal;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemOfertaHandbal;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemOfertaRugby;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemPrint;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSalveazaF;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}